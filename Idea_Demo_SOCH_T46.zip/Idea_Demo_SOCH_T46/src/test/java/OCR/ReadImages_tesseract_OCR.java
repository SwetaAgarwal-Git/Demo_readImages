package OCR;

import java.io.File;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

public class ReadImages_tesseract_OCR {

	public static void main(String[] args) {
		
		ITesseract image = new Tesseract();
		try {
			String imageText = image.doOCR(new File("C:\\Users\\04211Q744\\eclipse-workspace\\f2i\\images\\certificate security &privacy.png"));
			System.out.println(imageText);
		} catch (TesseractException e) {
			System.out.println("Exception details:" + e.getMessage());
		}		

	}

}
