package OCR;

import java.io.File;
import java.io.IOException;

import com.asprise.ocr.Ocr;

public class ReadImages_pdf_aspire_OCR {

	public static void main(String[] args) 
	
		throws IOException {

	        Ocr ocr = new Ocr(); // create a new OCR engine
	        ocr.startEngine("eng", Ocr.SPEED_FASTEST); // English

	        String s = ocr.recognize(new File[] { new File("C:\\Users\\04211Q744\\Downloads\\asprise-ocr-java-15.3.1-trial-windows\\img\\test1.png") },
	                Ocr.RECOGNIZE_TYPE_TEXT, Ocr.OUTPUT_FORMAT_PLAINTEXT);
	        System.out.println(s);
	        ocr.stopEngine();
		
		
}
	

}
