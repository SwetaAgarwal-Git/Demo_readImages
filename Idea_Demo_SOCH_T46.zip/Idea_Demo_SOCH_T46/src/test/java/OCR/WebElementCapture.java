package OCR;



import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WrapsDriver;


public class WebElementCapture {

	/**
	 * Gets a picture of specific element displayed on the page
	 * @param element The element
	 * @return File
	 * @throws Exception
	 */
	public static File captureElementPicture(WebElement element)
			throws Exception {

		// get the WrapsDriver of the WebElement
		WrapsDriver wrapsDriver = (WrapsDriver) element;
		
		/*
        // get the entire screenshot from the driver of passed WebElement
        File screen = ((TakesScreenshot) wrapsDriver.getWrappedDriver())
                .getScreenshotAs(OutputType.FILE);
		 */

		
		// get the screenshot from the driver of passed WebElement
		File screen2 = element.getScreenshotAs(OutputType.FILE);

		// create an instance of buffered image from captured screenshot
		BufferedImage img = ImageIO.read(screen2);

		return screen2;
	}
}