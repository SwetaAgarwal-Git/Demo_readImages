package test;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import OCR.WebElementCapture;
import io.github.bonigarcia.wdm.WebDriverManager;
import net.sourceforge.tess4j.Tesseract;

public class OCR_images_demo_test {

	static WebDriver driver = null;

	public static void main(String[] args) throws Exception {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		// go to application URL
		driver.get("https://www.reflectionsoflife1.com/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// get and capture the picture of the img element used to display the image
		WebElement Image = driver.findElement(By.xpath("//*[@id=\"left\"]/div/div/div[1]/div/div"));

		//capturing image of weblement 
		File imageFile = WebElementCapture.captureElementPicture(Image);

		// get the Tesseract direct interace
		Tesseract instance = new Tesseract();

		// the doOCR method of Tesseract will retrive the text from image captured by Selenium
		String result = instance.doOCR(imageFile);

		System.out.println(result);
		if(result.contains("optimistic")) {

			System.out.println("Next Actions can be performed - demo completed");
		}
		else {
			System.out.println("No text found. No action can be performed - demo completed");
		}


		driver.close();

		driver.quit();


	}


}
